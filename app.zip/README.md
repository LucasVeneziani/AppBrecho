# AppBrechó

Expo (SDK 57) app for brechós: point the camera at clothing or any other object (or its barcode/QR code), tap the search button and get what it is, a second-hand price range and similar listings found online.

## Flow

1. **Login / cadastro**: dark gray-blue screen. Register asks for usuário, e-mail and a strong password (8+ chars, upper, lower, number, special character), checked live by regex. Accounts are stored locally in SQLite (salted SHA-256).
2. **Permissão da câmera** right after login.
3. **Scanner** (main screen): full-screen camera, flash toggle, menu (Configurações / Sair), last-scan thumbnail, round search button and the bottom bar (Histórico, Escanear, Configurações).
4. **Código de barras / QR code**: when the camera sees a barcode (EAN, UPC, Code 128...) or a QR code, a chip shows the code with a *Buscar* button. This works for any object, not only clothing: the backend looks the code up (Open Food Facts, UPCitemdb, or the page a QR link points to), searches stores, and the AI fills in the result.
5. **Resultado**: overlay on the top 50% of the screen with the photo; scroll inside it (or expand) for details, price range, care tips and listings.
6. **Histórico**: overlay listing every scan of the logged-in user, sortable *Último → primeiro* / *Primeiro → último* by scan date. Photos are saved as BLOBs in SQLite.
7. **Configurações**: overlay with a scrollable list of settings (for now: dark mode).

## Run

```bash
python backend/run.py         # terminal 1: sets up and starts the AI backend, and points the app's .env at it
npm install                   # terminal 2 (first time only)
npx expo start                # scan the QR code with Expo Go
```

The AI backend (Python, OpenRouter + web crawling) lives in [`backend/`](backend/README.md) and must be running for scans to work.
On a physical phone `EXPO_PUBLIC_API_URL` must be your computer's LAN IP (e.g. `http://192.168.0.10:8000`), not `localhost`.

## Layout

- `src/app/` routes (expo-router): `login`, `permission`, `scanner`, `result/[id]`, `history`, `settings`
- `src/lib/` SQLite schema and queries, auth, theme, API client
- `src/components/` bottom bar and overlay containers
- `backend/` FastAPI service
